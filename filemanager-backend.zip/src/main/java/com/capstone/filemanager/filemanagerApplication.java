package com.capstone.filemanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class filemanagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(filemanagerApplication.class, args);
	}

}
